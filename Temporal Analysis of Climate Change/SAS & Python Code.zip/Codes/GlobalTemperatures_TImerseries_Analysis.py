#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
sns.set(style="ticks", color_codes=True)

get_ipython().run_line_magic('matplotlib', 'inline')

import os
import io

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=UserWarning)

import chart_studio.plotly as py
import plotly.express as px
import plotly.graph_objects as go
import colorlover as cl
from plotly.subplots import make_subplots


# In[2]:


gt=pd.read_csv('GlobalTemperatures.csv', parse_dates=['dt'])


# In[3]:


gt.head()


# In[4]:


gt.isnull().sum()


# In[5]:


gt.shape


# In[6]:


gt.describe()


# There are 1200 values missing from different columns, which are years from 1750- 1850

# In[7]:


gt=gt.dropna().reset_index()


# In[8]:


gt.head()


# In[9]:


gt=gt.drop('index', axis=1)
gt.columns


# In[10]:


df=gt[['dt', 'LandAverageTemperature','LandMaxTemperature','LandMinTemperature','LandAndOceanAverageTemperature']]
df.head()


# In[11]:


df['year'] = df['dt'].dt.year
df['month'] = df['dt'].dt.month


# In[12]:


df.head()


# In[13]:


fig, ((ax0), (ax1)) = plt.subplots(2,1, figsize=(20, 20))
fig=sns.lineplot(x='year', y='LandAverageTemperature', data=df, ax=ax0)
fig=sns.lineplot(x='year', y='LandMaxTemperature', data=df, ax=ax0)
fig=sns.lineplot(x='year', y='LandMinTemperature', data=df, ax=ax0)
fig=sns.lineplot(x='year', y='LandAndOceanAverageTemperature', data=df, ax=ax1)
ax0.set_title('Temperatures over the years ')
ax1.set_title('Land and Ocean Average Temperature')
plt.ylabel('Temperature', fontsize=20, fontweight='bold')
plt.xlabel('Year', fontsize=20, fontweight='bold')
plt.show()


# From the graph, i can see that the change in temperature is significant after hte year 1970. Therefore, i Want to take this year as key point, for Climate Change. The reason for this can be explained through increase in consumption of Oil, Gas and Coal from this period.

# ### Plotly Graphs with Averages

# In[14]:


df_temp=df.groupby(['year']).mean().reset_index()
df_temp


# #### Average Temperature

# In[15]:


#Lets also plot Moving Average of the decase to decrease the variation
df_temp['Decade_MA_LAT'] = df_temp['LandAverageTemperature'].rolling(10).mean()


fig = make_subplots(rows=1, cols=1, insets=[{'cell': (1,1), 'l': 0.7, 'b': 0.3}])
fig.update_layout(title="Land Average Temperature: 1850-2015", title_font_size = 20,
                  font=dict( family="Courier New, monospace", size=12,color="#7f7f7f"),
                  template = "ggplot2", hovermode= 'closest')
fig.update_xaxes(showline=True, linewidth=1, linecolor='gray')
fig.update_yaxes(showline=True, linewidth=1, linecolor='gray')

fig.add_trace(go.Scatter(x = df_temp['year'], y = df_temp['LandAverageTemperature'], mode = 'lines',
                        name = 'Land Avg Temp', marker_color='rgb(128, 0, 0)'))
fig.add_trace(go.Scatter( x=[1970, 1970], y=[7.5, 10], mode="lines",line=go.scatter.Line(color="gray"), showlegend=False),
             row = 1, col = 1)
fig.add_trace(go.Scatter( x=df_temp['year'], y = df_temp['Decade_MA_LAT'], mode="lines",line=go.scatter.Line(color="gray"),
                         showlegend=False),
             row = 1, col = 1)


# In[16]:


#Lets also plot Moving Average of the decase to decrease the variation
df_temp['Decade_MA_LMT'] = df_temp['LandMaxTemperature'].rolling(10).mean()


fig = make_subplots(rows=1, cols=1, insets=[{'cell': (1,1), 'l': 0.7, 'b': 0.3}])
fig.update_layout(title="Land MAX Temperature: 1850-2015", title_font_size = 20,
                  font=dict( family="Courier New, monospace", size=12,color="#7f7f7f"),
                  template = "ggplot2", hovermode= 'closest')
fig.update_xaxes(showline=True, linewidth=1, linecolor='gray')
fig.update_yaxes(showline=True, linewidth=1, linecolor='gray')

fig.add_trace(go.Scatter(x = df_temp['year'], y = df_temp['LandMaxTemperature'], mode = 'lines',
                        name = 'Land Avg Temp', marker_color='rgb(128, 0, 0)'))
fig.add_trace(go.Scatter( x=[1970, 1970], y=[12, 16], mode="lines",line=go.scatter.Line(color="gray"), showlegend=False),
             row = 1, col = 1)
fig.add_trace(go.Scatter( x=df_temp['year'], y = df_temp['Decade_MA_LMT'], mode="lines",line=go.scatter.Line(color="gray"),
                         showlegend=False),
             row = 1, col = 1)


# In[17]:


#Lets also plot Moving Average of the decase to decrease the variation
df_temp['Decade_MA_LMinT'] = df_temp['LandMinTemperature'].rolling(10).mean()


fig = make_subplots(rows=1, cols=1, insets=[{'cell': (1,1), 'l': 0.7, 'b': 0.3}])
fig.update_layout(title="Land Min Temperature: 1850-2015", title_font_size = 20,
                  font=dict( family="Courier New, monospace", size=12,color="#7f7f7f"),
                  template = "ggplot2", hovermode= 'closest')
fig.update_xaxes(showline=True, linewidth=1, linecolor='gray')
fig.update_yaxes(showline=True, linewidth=1, linecolor='gray')

fig.add_trace(go.Scatter(x = df_temp['year'], y = df_temp['LandMinTemperature'], mode = 'lines',
                        name = 'Land Avg Temp', marker_color='rgb(128, 0, 0)'))
fig.add_trace(go.Scatter( x=[1970, 1970], y=[0, 5], mode="lines",line=go.scatter.Line(color="gray"), showlegend=False),
             row = 1, col = 1)
fig.add_trace(go.Scatter( x=df_temp['year'], y = df_temp['Decade_MA_LMinT'], mode="lines",line=go.scatter.Line(color="gray"),
                         showlegend=False),
             row = 1, col = 1)


# In[18]:


#Lets also plot Moving Average of the decase to decrease the variation
df_temp['Decade_MA_Ocean'] = df_temp['LandAndOceanAverageTemperature'].rolling(10).mean()


fig = make_subplots(rows=1, cols=1, insets=[{'cell': (1,1), 'l': 0.7, 'b': 0.3}])
fig.update_layout(title="Land Average Temperature: 1850-2012", title_font_size = 20,
                  font=dict( family="Courier New, monospace", size=12,color="#7f7f7f"),
                  template = "ggplot2", hovermode= 'closest')
fig.update_xaxes(showline=True, linewidth=1, linecolor='gray')
fig.update_yaxes(showline=True, linewidth=1, linecolor='gray')

fig.add_trace(go.Scatter(x = df_temp['year'], y = df_temp['LandAndOceanAverageTemperature'], mode = 'lines',
                        name = 'Land Avg Temp', marker_color='rgb(128, 0, 0)'))
fig.add_trace(go.Scatter( x=[1970, 1970], y=[14, 18], mode="lines",line=go.scatter.Line(color="gray"), showlegend=False),
             row = 1, col = 1)
fig.add_trace(go.Scatter( x=df_temp['year'], y = df_temp['Decade_MA_Ocean'], mode="lines",line=go.scatter.Line(color="gray"),
                         showlegend=False),
             row = 1, col = 1)


# ## Data Preparation

# In[19]:


df_land=df[['LandAverageTemperature']]
df_land.index=df['dt']


# In[20]:


df_land.head()


# In[21]:


df.shape


# 1992/12= 166, we have data of 166 years. I would like to divide the data into train, val and test. With last 5 years as test set, before that 38 years as val set 

# In[22]:


test=df_land[-12:]
val=df_land[-60:-12]
train=df_land[:-60]
print(f'Training set:{train.count()}, validation_Set:{val.count()}, Test set:{test.count()}' )


# ## Series Analysis

# #### stationary

# In[23]:


from statsmodels.tsa.stattools import adfuller

results = adfuller(train['LandAverageTemperature'])
adftest = pd.Series(results[0:4], index=['Test Statistic','p-value','Lags Used','Number of Observations Used'])
adftest = round(adftest,4)

print(adftest)
print('The p-value of the test on prices is: ' + str(adftest[1]))


# In[24]:


from statsmodels.graphics.tsaplots import plot_acf,plot_pacf
fig, (ax1,ax2)=plt.subplots(2,1, figsize=(10,10))
plot_acf(train.LandAverageTemperature, alpha=0.05, lags=48, ax=ax1)
plot_pacf(train.LandAverageTemperature, lags=12,ax=ax2)
plt.show()


#   1. From the Autocorrelation graph, we can see that for every 12 points the series is coming to zero and hterefore the seasonality is yearly
#   2. From the partial  autocorrelation, the correlation is not dropping to less than zero

# ### Trend Analysis

# In[25]:


moving_average = train['LandAverageTemperature'].rolling(window=48).mean()
plt.plot(moving_average, color = 'red') 
plt.show()


# We can see a steady increase in the average temperature with moving average increasing from 8 to 10

# #### Differencing to remove Non stationary

# In[26]:


#From the auto correlation,w e can see that for every 12 pouints, the graph is coming back to zero. 
#The negatove auto correltion indicates change of season to winter, while temperatures are higher in summer.

yearly_change=train.diff(12)
yearly_change=yearly_change.dropna()

autocorrelation_yearly = yearly_change['LandAverageTemperature'].autocorr()
print("The autocorrelation of annual interest rate changes is %4.2f" %(autocorrelation_yearly))


# In[28]:


#Dickey-Fuller Test for differnced series

results = adfuller(yearly_change['LandAverageTemperature'])
adftest = pd.Series(results[0:4], index=['Test Statistic','p-value','Lags Used','Number of Observations Used'])
adftest = round(adftest,4)

print(adftest)
print('The p-value of the test on prices is: ' + str(adftest[1]))


# Now we can see that p-value is zero and therefore, series has become stationary with lags as 12

# In[48]:


from statsmodels.graphics.tsaplots import plot_acf,plot_pacf
fig, (ax1,ax2)=plt.subplots(2,1, figsize=(10,10))
plot_acf(yearly_change.LandAverageTemperature, alpha=0.05, lags=12, ax=ax1)
plot_pacf(yearly_change.LandAverageTemperature, lags=24,ax=ax2)
plt.show()


# We can see that ACF model is tailing off while PACF is cut off at 1, which shows that it is a AR(4) model. Also we can see that at lag 12 , we see a large negative spike which indicate dos SAR(1) due to first difference taken at lag 12
# 

# In[30]:


# Make list of lags
lags = [12, 24, 36, 48, 60]

# Create the figure 
fig, (ax1, ax2) = plt.subplots(2,1,figsize=(8,6))

# Plot the ACF on ax1
plot_acf(yearly_change, lags=lags, zero=False, ax=ax1)

# Plot the PACF on ax2
plot_pacf(yearly_change, lags=lags, zero=False, ax=ax2)

plt.show()


# #### White Noise Test

# In[31]:


from statsmodels.stats.diagnostic import acorr_ljungbox
lb_test= acorr_ljungbox(yearly_change['LandAverageTemperature'], lags=[24],boxpierce=True)
print('P-values are: ', lb_test[1])


# As the p value is less than 5%, we can therefore confirm that there is no white noise

# ## Modelling and Forecasting

# Let find the order

# In[33]:


train['LandAverageTemperature'].dropna(inplace=True)
val['LandAverageTemperature']=val['LandAverageTemperature'].shift()
val['LandAverageTemperature'].dropna(inplace=True)


# In[39]:


import warnings

warnings.simplefilter('ignore')
import statsmodels.api as sm


aic_full = pd.DataFrame(np.zeros((6,6), dtype=float))
aic_miss = pd.DataFrame(np.zeros((6,6), dtype=float))


order_aic_bic=[]
seasonal_order_Aic_Bic=[]

for p in range(4):
    for q in range(2):
        if p == 0 and q == 0:
            continue
        
        mod = sm.tsa.statespace.SARIMAX(train['LandAverageTemperature'], order=(p,0,q),seasonal_order=(0, 1, 1, 12),
                                        trend='c')
        try:
            res = mod.fit(disp=False)
            aic_full.iloc[p,q] = res.aic
        except:
            aic_full.iloc[p,q] = np.nan
        order_aic_bic.append((p,q,res.aic, res.bic))


# In[40]:


order_df = pd.DataFrame(order_aic_bic, 
                        columns=['p', 'q', 'AIC', 'BIC'])

# Print order_df in order of increasing AIC
print(order_df.sort_values(by='AIC'))

# Print order_df in order of increasing BIC
print(order_df.sort_values(by='BIC'))


# Both the AIC and BIC are to be minimized for a good model. Therefore, a good model is with AR(2) as indicated in Auto correlation graph

# ### Model Building

# In[93]:


mod = sm.tsa.statespace.SARIMAX(df_land['LandAverageTemperature'], order=(2,1,1), seasonal_order=(0,1,1,12))
res = mod.fit(disp=False)
print(res.summary())


# If proh(JB)<0.05, we will reject the null hypothesis that it is normally distributed
# if prob(Q<0.05, the series is stationary

# In[94]:


fig=plt.figure()
fig= res.plot_diagnostics()
fig.set_size_inches(15,12)
plt.show()


# The residuals are not normally distributed and normal Q-Q plots show that at both the ends there is a huge outliers located

# In[96]:


mae = np.mean(np.abs(res.resid))

# Print mean absolute error
print(mae)


# In[102]:


# Create SARIMA mean forecast unitll 2025
sarima_pred = res.get_forecast(steps=600)
sarima_mean = sarima_pred.predicted_mean
plt.figure(figsize=(15,7))
plt.plot(sarima_mean, label='SARIMA')
plt.plot(df_land['LandAverageTemperature'])
plt.legend()
plt.show()


# In[103]:


# Create forecast object
forecast_object = res.get_forecast(steps=120)

# Extract predicted mean attribute
mean = forecast_object.predicted_mean

# Calculate the confidence intervals
conf_int = forecast_object.conf_int()

# Extract the forecast dates
dates = mean.index


# In[108]:


plt.figure(figsize=(20,10))

# Plot the prediction means as line
plt.plot(dates, mean, label='predicted')

# Shade between the confidence intervals
plt.fill_between(dates, conf_int.iloc[:,0], conf_int.iloc[:,1], alpha=0.2)

# Plot legend and show figure
plt.legend()
plt.tick_params(axis='both', which='major', labelsize=30)
plt.tick_params(axis='both', which='minor', labelsize=30)
plt.show()


# In[109]:


# Print last predicted mean
print(mean.iloc[-1])

# Print last confidence interval
print(conf_int.iloc[-1])

