#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
sns.set(style="ticks", color_codes=True)

get_ipython().run_line_magic('matplotlib', 'inline')

import os
import io

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=UserWarning)

import plotly.offline as py
py.init_notebook_mode(connected=True)
import plotly.graph_objs as go


# In[2]:


clim=pd.read_excel('GlobalLandTemperaturesByMajorCity.xlsx', parse_dates=['dt'])


# In[3]:


clim.head()


# ## Major Coastal Cities

# The idea of the this kernel is to check the variation of temperature among Major coastal cities and check if the temperature raise is similar among all these

# In[4]:


clim.City.unique()


# In[5]:


madras=clim[clim['City']=='Madras']
capetown=clim[clim['City']=='Cape Town']
losAngeles=clim[clim['City']=='Los Angeles']
shanghai=clim[clim['City']=='Shanghai']
rio=clim[clim['City']=='Rio De Janeiro']


# In[6]:


print(madras.shape)
print(capetown.shape)
print(losAngeles.shape)
print(shanghai.shape)
print(rio.shape)


# We have 112 years of data of Temperature, averaged monthly.

# In[7]:


madras=madras[['dt', 'AverageTemperature']]
capetown=capetown[['dt', 'AverageTemperature']]
losangeles=losAngeles[['dt', 'AverageTemperature']]
shanghai=shanghai[['dt', 'AverageTemperature']]
rio=rio[['dt', 'AverageTemperature']]


# In[8]:


madras=madras.set_index('dt')
capetown=capetown.set_index('dt')
losangeles=losangeles.set_index('dt')
shanghai=shanghai.set_index('dt')
rio=rio.set_index('dt')


# In[9]:


fig, ((ax0),(ax1),(ax2),(ax3),(ax4)) = plt.subplots(5,1, figsize=(20, 40))
fig=sns.lineplot(x=madras.index, y='AverageTemperature', data=madras, ax=ax0)
fig=sns.lineplot(x=capetown.index, y='AverageTemperature', data=capetown, ax=ax1)
fig=sns.lineplot(x=losangeles.index, y='AverageTemperature', data=losangeles, ax=ax2)
fig=sns.lineplot(x=shanghai.index, y='AverageTemperature', data=shanghai, ax=ax3)
fig=sns.lineplot(x=rio.index, y='AverageTemperature', data=rio, ax=ax4)
plt.xticks(fontsize=30)
plt.yticks(fontsize=30)
plt.ylabel('AverageTemperature', fontsize=20, fontweight='bold')
plt.xlabel('Year', fontsize=20, fontweight='bold')
plt.show()


# From the figure, we can see that there is a lot of seasonality in the data as expecetd to be in a year. Lets check the variationn by month and by year

# ### Monthly variation 

# In[10]:


cities=[madras, capetown, losangeles, shanghai, rio]

for i in cities:
    i['month']=i.index.month
    i['year']=i.index.year
    


# In[11]:


madras.head()


# In[12]:


pivot_m= pd.pivot_table(madras, index='month', columns='year', aggfunc='mean')
pivot_c= pd.pivot_table(capetown, index='month', columns='year', aggfunc='mean')
pivot_l= pd.pivot_table(losangeles, index='month', columns='year', aggfunc='mean')
pivot_s= pd.pivot_table(shanghai, index='month', columns='year', aggfunc='mean')
pivot_r= pd.pivot_table(rio, index='month', columns='year', aggfunc='mean')


# In[13]:


pivots=[pivot_m, pivot_c, pivot_l, pivot_s, pivot_r]

for i in pivots:
    i.plot(figsize=(20,10))
    plt.title('yearly Temperatures')
    plt.xlabel('Months')
    plt.ylabel('Average Temperature in a month')
    plt.xticks([x for x in range(1,13)])
    plt.legend().remove()
    plt.show()


# ### Variation in a Year(seasonality)

# In[14]:


pivot_ms= pd.pivot_table(madras, index='month', columns='year',values='AverageTemperature', aggfunc='mean')
pivot_cs= pd.pivot_table(capetown, index='month', columns='year',values='AverageTemperature', aggfunc='mean')
pivot_ls= pd.pivot_table(losangeles, index='month', columns='year',values='AverageTemperature', aggfunc='mean')
pivot_ss= pd.pivot_table(shanghai, index='month', columns='year',values='AverageTemperature', aggfunc='mean')
pivot_rs= pd.pivot_table(rio, index='month', columns='year', values='AverageTemperature',aggfunc='mean')


# In[15]:


pivotss=[pivot_ms, pivot_cs, pivot_ls, pivot_ss, pivot_rs]
for i in pivotss:
    monthly_seasonality = i.mean(axis=1)
    monthly_seasonality.plot(figsize=(20,6))
    plt.title('Monthly Temperatures')
    plt.xlabel('Months')
    plt.ylabel('Temperature')
    plt.xticks([x for x in range(1,13)])
    plt.show()


# ### Temperature Change Using Moving Average

# In[16]:


pivot_my= pd.pivot_table(madras, index='year', values='AverageTemperature', aggfunc='mean')
pivot_cy= pd.pivot_table(capetown, index='year', values='AverageTemperature', aggfunc='mean')
pivot_ly= pd.pivot_table(losangeles, index='year', values='AverageTemperature', aggfunc='mean')
pivot_sy= pd.pivot_table(shanghai, index='year', values='AverageTemperature', aggfunc='mean')
pivot_ry= pd.pivot_table(rio, index='year', values='AverageTemperature', aggfunc='mean')


# In[17]:


pivoty=[pivot_my, pivot_cy, pivot_ly, pivot_sy, pivot_ry]
for i in pivoty:
    i['Decade MA'] = i['AverageTemperature'].rolling(10).mean()
    i[['AverageTemperature','Decade MA']].plot(figsize=(20,6))
    plt.title('Yearly trend of Average Temperatures')
    plt.xlabel('year')
    plt.ylabel('Average Temperature by year')
    plt.xticks([x for x in range(1900, 2012, 4)])
    plt.legend().remove()
    plt.show()


# We can see that in if we take, 10 years average, the growth is linearly increasing.<br>
# From all the five graphs we can see that, there is substantial increase of 1 degree in 120 years.

# ### Percentage Change in temperature

# In[18]:


pivot_myd=pivot_my.pct_change()*100
pivot_cyd=pivot_cy.pct_change()*100
pivot_lyd=pivot_ly.pct_change()*100
pivot_syd=pivot_sy.pct_change()*100
pivot_ryd=pivot_ry.pct_change()*100


# In[19]:


pivot_myd.head()


# In[20]:


pivotd=[pivot_myd, pivot_cyd, pivot_lyd, pivot_syd, pivot_ryd]
for i in pivotd:
    i['Decade MA'] = i['AverageTemperature'].rolling(10).mean()
    i[['AverageTemperature','Decade MA']].plot(figsize=(20,6))
    plt.title('Yearly trend of Average Temperatures')
    plt.xlabel('year')
    plt.ylabel('Average Temperature by year')
    plt.xticks([x for x in range(1900, 2012, 4)])
    plt.legend().remove()
    plt.show()

